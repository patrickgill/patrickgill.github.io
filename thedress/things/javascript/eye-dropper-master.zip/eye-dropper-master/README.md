### Eye Dropper

An eye dropper tool on the web. Paste an image into the window, and mouse over it to extract colors.

### Site
http://kentor.github.io/eye-dropper/
